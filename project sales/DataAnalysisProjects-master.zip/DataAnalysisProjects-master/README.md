# To download SQL dump files and other files

To download SQL dump files and other files for any of the projects in this repository, please click on green Code button at top right and click on Download Zip as shown below. 

![download_help](https://user-images.githubusercontent.com/60363945/180615052-05d1b0a2-d4af-4eca-9b23-23ed4042961e.png)
